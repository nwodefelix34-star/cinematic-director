
import { GoogleGenAI, GenerateContentResponse, Modality, Type } from "@google/genai";

// Standard AI fetch utility - creates a fresh instance per call to pick up the most current API key
const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Generates 10 viral story ideas based on a topic or randomly.
 */
export const generateIdeas = async (topic: string): Promise<string[]> => {
  const ai = getAI();
  const prompt = topic 
    ? `Generate 10 viral, high-retention YouTube video story ideas about "${topic}". Focus on educational, "zachdfilms-style" animation concepts or fascinating, surprising facts. Provide snappy, curiosity-driven titles/hooks.`
    : `Generate 10 random viral, high-retention YouTube video story ideas. Focus on educational, fascinating facts, or "how things work" concepts (similar to zachdfilms). Provide snappy, curiosity-driven titles/hooks.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: { type: Type.STRING }
      }
    }
  });

  try {
    return JSON.parse(response.text || "[]");
  } catch (e) {
    console.error("Failed to parse ideas:", e);
    return [];
  }
};

/**
 * Enhances a style description into a high-quality visual prompt.
 */
export const generateCustomStyle = async (topic: string, currentContext: string): Promise<string> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Based on the topic "${topic}" and this context: "${currentContext}", brainstorm a unique and visually stunning art style for a viral YouTube video. Focus on 3D educational animation aesthetics.
    Provide only a one-sentence highly descriptive style prompt that focuses on texture, lighting, and artistic medium (e.g. "Hyper-clean 3D claymation with soft sub-surface scattering and vibrant educational lighting").`,
    config: {
      thinkingConfig: { thinkingBudget: 8000 }
    }
  });
  return response.text?.trim() || "Cinematic 8k realism, educational 3D style";
};

/**
 * Generates a full multi-scene storyboard based on a topic.
 */
export const generateStoryboard = async (topic: string, isShort: boolean, numScenes: number = 5): Promise<{
  title: string;
  storyArc: string;
  globalContext: string;
  visualStyle: string;
  scenes: { prompt: string; narration: string; sfx: string }[];
  musicVibe: string;
}> => {
  const ai = getAI();
  const format = isShort ? "YouTube Short (9:16)" : "Cinematic (16:9)";
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Create an engaging ${numScenes}-scene storyboard for a ${format} viral YouTube story: "${topic}". 
    The script should be snappy, educational, and designed for retention.
    
    Provide a "globalContext" for character/world consistency and a "visualStyle" (e.g., "Hyper-realistic 3D", "zachdfilms-style animation", "Vibrant Digital Anime").
    
    For each scene, provide a descriptive visual prompt, narration script, and an atmospheric sound effect (SFX) idea.
    The response must be in JSON format.`,
    config: {
      thinkingConfig: { thinkingBudget: 32768 },
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          storyArc: { type: Type.STRING },
          globalContext: { type: Type.STRING },
          visualStyle: { type: Type.STRING },
          musicVibe: { type: Type.STRING },
          scenes: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                prompt: { type: Type.STRING },
                narration: { type: Type.STRING },
                sfx: { type: Type.STRING }
              },
              required: ["prompt", "narration", "sfx"]
            }
          }
        },
        required: ["title", "scenes", "musicVibe", "storyArc", "globalContext", "visualStyle"]
      }
    }
  });

  try {
    return JSON.parse(response.text || "{}");
  } catch (e) {
    throw new Error("Failed to parse storyboard JSON");
  }
};

/**
 * Uses Gemini Pro to optimize a user prompt for high-quality video generation.
 */
export const enhancePrompt = async (userPrompt: string): Promise<string> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Rewrite this prompt to be hyper-descriptive, cinematic, and detailed, similar to the output of a high-end 3D animation director. Focus on technical motion, volumetric lighting, and material textures. Original: "${userPrompt}"`,
    config: {
      thinkingConfig: { thinkingBudget: 16000 }
    }
  });
  return response.text || userPrompt;
};

/**
 * Generates an image for a specific scene.
 */
export const generateImage = async (prompt: string, aspectRatio: '16:9' | '9:16' = '9:16', globalContext?: string, visualStyle?: string): Promise<string> => {
  const ai = getAI();
  const fullPrompt = `Artistic Style: ${visualStyle || 'Cinematic'}. 
    World Context: ${globalContext || ''}. 
    Scene: ${prompt}. 
    Requirement: Professional 3D lighting, cinematic composition, high fidelity.`;

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [{ text: fullPrompt }]
    },
    config: {
      imageConfig: {
        aspectRatio: aspectRatio,
      }
    },
  });

  const part = response.candidates?.[0]?.content?.parts.find(p => p.inlineData);
  if (part?.inlineData) {
    return `data:image/png;base64,${part.inlineData.data}`;
  }
  throw new Error("No image data found in response");
};

/**
 * Generates a video from an image using the Veo 3.1 model.
 */
export const generateVideo = async (
  prompt: string, 
  base64Image: string, 
  aspectRatio: '16:9' | '9:16' = '9:16',
  visualStyle?: string,
  globalContext?: string,
  resolution: '720p' | '1080p' = '1080p'
): Promise<string> => {
  const ai = getAI();
  
  // Refine the prompt specifically for video motion
  const imagineResponse = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Create a cinematic motion directive for this scene: "${prompt}". 
    The style is ${visualStyle} and world context is ${globalContext}.
    Describe specifically the camera movement and character motion. Provide 2 sentences max.`,
    config: { thinkingConfig: { thinkingBudget: 4000 } }
  });

  const imaginedPrompt = imagineResponse.text || prompt;
  
  let operation = await ai.models.generateVideos({
    model: 'veo-3.1-generate-preview',
    prompt: imaginedPrompt,
    image: {
      imageBytes: base64Image.split(',')[1],
      mimeType: 'image/png',
    },
    config: {
      numberOfVideos: 1,
      resolution: resolution,
      aspectRatio: aspectRatio
    }
  });

  // Long polling for video completion
  while (!operation.done) {
    await new Promise(resolve => setTimeout(resolve, 15000));
    operation = await ai.operations.getVideosOperation({operation: operation});
  }

  const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
  if (!downloadLink) throw new Error("Video generation failed: No URI returned.");

  const videoResponse = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
  const blob = await videoResponse.blob();
  return URL.createObjectURL(blob);
}

/**
 * Synthesizes speech for a script.
 */
export const generateNarration = async (
  script: string, 
  voiceName: string = 'Zephyr', 
  styleInstruction: string = '',
  speed: 'slow' | 'normal' | 'fast' = 'normal',
  energy: 'low' | 'normal' | 'high' = 'normal'
) => {
  const ai = getAI();
  const speedText = speed === 'fast' ? 'quickly' : speed === 'slow' ? 'slowly' : 'naturally';
  const energyText = energy === 'high' ? 'energetically' : energy === 'low' ? 'calmly' : 'professionally';
  const finalPrompt = `Instruction: ${styleInstruction || 'Narrate clearly'}. Speak ${speedText} and ${energyText}. Script: ${script}`;

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text: finalPrompt }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: voiceName as any },
        },
      },
    },
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) throw new Error("No audio data received");
  return base64Audio;
};

// Utils for audio context decoding
export function decodeBase64(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

export async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer, data.byteOffset, data.byteLength / 2);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}
